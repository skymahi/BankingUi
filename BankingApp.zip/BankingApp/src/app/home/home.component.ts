import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})

export class HomeComponent {
  balance: number = 0;
  depositAmount: number = 0;
  withdrawAmount: number = 0;

  constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {
    this.fetchBalance();
  }

  fetchBalance(): void {
    this.userService.getBalance().subscribe({
      next: (data) => (this.balance = data.balance),
      error: (err) => console.error('Error fetching balance:', err),
    });
  }

  withdraw(): void {
    if (this.withdrawAmount > 0) {
      this.userService.withdraw(this.withdrawAmount).subscribe({
        next: (data) => {
          this.balance = data.balance;
          this.withdrawAmount = 0;
        },
        error: (err) => console.error('Error during withdrawal:', err),
      });
    }
  }

  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}
