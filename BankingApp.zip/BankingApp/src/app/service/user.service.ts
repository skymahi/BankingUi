import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Observable, of, throwError } from 'rxjs';
@Injectable()
export class UserService {

  constructor(private http: HttpClient) {}

  login(username: string, password: string): Observable<{ token: string }> {
    return this.http.post<{ token: string }>(
      'https://localhost:7016/api/auth/login',
      { username, password }
    );
  }

  getBalance(): Observable<{ balance: number }> {
    return this.http.get<{ balance: number }>(
      'https://localhost:7016/api/banking/balance'
    );
  }

  deposit(amount: number): Observable<{ balance: number }> {
    return this.http.post<{ balance: number }>(
      'https://localhost:7016/api/banking/deposit',
      { amount }
    );
  }

  withdraw(amount: number): Observable<{ balance: number }> {
    return this.http.post<{ balance: number }>(
      'https://localhost:7016/api/banking/withdraw',
      { amount }
    );
  }
}
